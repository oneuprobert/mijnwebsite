<script type="text/javascript">
var ageCheck = window.prompt("Verifier votre age SVP:")

if (ageCheck < 18) {

    window.alert("Vous n'avez pas le droit d'entrer sur notre site.");
    location.href("http://www.google.com");
}

    else if (ageCheck > 18 && ageCheck <101 ) {

        window.alert("Bienvenu sur Lovenow.ch");




    }

</script>